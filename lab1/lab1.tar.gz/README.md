Team
=====
Team size: 2

<br/><br/>

Member 1
Praveen Kumar Pendyala
2919474
praveenkumar.pendyala@stud.tu-darmstadt.de

<br/><br/>

Member 2
Ankush Chikhale
2973449
ankush.chikhale@stud.tu-darmstadt.de

Note
======
Each solution works independently as a single file.

Compile and execute
=====================
No rocket science in compile and exec commands. Just the usual command with Wall flag.

For pro-man.c, ipc-pipe.c
```
gcc -Wall -o file.o file.c
```


For the rest
```
gcc -Wall -o file.o file.c -lrt
```

Disclaimer
===========
All codes enclosed in this submission / folder are written by the submitter(s) / repository owner. 
Any resemblence to other codes is pure coincidence (Shakespeare Infinite monkey theorem) 
or a dirty hack by the other team!
